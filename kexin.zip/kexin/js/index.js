$(function(){

});

//添加管理员
function addmanager(){

}










