
window.onload=function(){
	//alert(document.body.scrollHeight)
	// var id=1;
	// if(id!=1){
	// 	window.parent.document.getElementById('frame').style.height = (document.body.scrollHeight+200)+'px';
	// }else{
	// 	window.parent.document.getElementById('frame').style.height = (document.body.scrollHeight+200)+'px';
	// }
	
	// console.log(id);
}




