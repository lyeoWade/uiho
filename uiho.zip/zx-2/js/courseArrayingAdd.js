$(function(){
	
	//{ "action": "addOneTimetable","params":{"beginTime":"9:00","endTime":"10:00","periodType": 1,"price":"90" },"source":"web","target":"timetable"}
	timeTable();
});

